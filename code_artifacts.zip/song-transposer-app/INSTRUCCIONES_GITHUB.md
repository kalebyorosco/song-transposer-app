# 📝 Instrucciones para Crear el Repositorio en GitHub

## Archivos Preparados ✅

Todos los archivos están listos en: `/home/ubuntu/code_artifacts/song-transposer-app/`

- ✅ `main.py` - Aplicación FastAPI completa
- ✅ `requirements.txt` - Dependencias actualizadas (FastAPI 0.115.0)
- ✅ `Procfile` - Configuración para despliegue
- ✅ `README.md` - Documentación completa
- ✅ `.gitignore` - Archivos a ignorar
- ✅ Repositorio git inicializado

---

## Opción 1: Crear Repositorio desde la Web de GitHub (Más fácil) 🌐

### Paso 1: Crea el repositorio en GitHub
1. Ve a https://github.com/new
2. Nombre del repositorio: `song-transposer-app`
3. Descripción: "Web app para transponer canciones a diferentes tonalidades musicales"
4. Selecciona: **Public** (Público)
5. **NO marques** ninguna opción de inicializar con README, .gitignore, o licencia
6. Haz clic en **"Create repository"**

### Paso 2: Sube los archivos
Una vez creado el repositorio, GitHub te mostrará comandos. Copia y ejecuta estos comandos en tu terminal LOCAL:

```bash
# Navega a la carpeta del proyecto
cd /home/ubuntu/code_artifacts/song-transposer-app

# Conecta con tu repositorio de GitHub (REEMPLAZA "TU_USUARIO" con tu usuario de GitHub)
git remote add origin https://github.com/TU_USUARIO/song-transposer-app.git

# Cambia el nombre de la rama a main (si es necesario)
git branch -M main

# Sube los archivos
git push -u origin main
```

---

## Opción 2: Usar GitHub CLI (Si tienes gh instalado) 🖥️

```bash
# Navega a la carpeta
cd /home/ubuntu/code_artifacts/song-transposer-app

# Crea el repositorio y sube los archivos
gh repo create song-transposer-app --public --source=. --remote=origin --push
```

---

## Opción 3: Usar un Personal Access Token (PAT) 🔑

### Paso 1: Crea un Personal Access Token
1. Ve a: https://github.com/settings/tokens/new
2. Nombre: "Song Transposer App Upload"
3. Permisos necesarios: marca `repo` (acceso completo a repositorios)
4. Haz clic en **"Generate token"**
5. **COPIA EL TOKEN** (solo se muestra una vez)

### Paso 2: Ejecuta estos comandos

```bash
cd /home/ubuntu/code_artifacts/song-transposer-app

# Crea el repositorio usando la API de GitHub (REEMPLAZA TU_USUARIO y TU_TOKEN)
curl -H "Authorization: token TU_TOKEN" \
     -d '{"name":"song-transposer-app","description":"Web app para transponer canciones","public":true}' \
     https://api.github.com/user/repos

# Conecta y sube (REEMPLAZA TU_USUARIO y TU_TOKEN)
git remote add origin https://TU_TOKEN@github.com/TU_USUARIO/song-transposer-app.git
git branch -M main
git push -u origin main
```

---

## ✅ Verificación

Una vez subido, tu repositorio estará disponible en:
```
https://github.com/TU_USUARIO/song-transposer-app
```

Podrás verlo en tu perfil y compartirlo con otros. ¡Estará listo para desplegarse en plataformas como Render o Railway!

---

## 🆘 ¿Problemas?

Si tienes errores al subir, verifica:
- Que estás autenticado en Git: `git config --global user.name "Tu Nombre"`
- Que tienes permisos en el repositorio
- Que la URL del repositorio es correcta

---

**Nota:** Los archivos duplicados de requirements fueron identificados y eliminados. Se usa el archivo con las versiones más recientes de las dependencias (FastAPI 0.115.0).
