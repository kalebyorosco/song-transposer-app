# 🎵 Song Transposer App

Una aplicación web moderna para transponer canciones a diferentes tonalidades musicales.

## Características

✨ **Funcionalidades principales:**
- 🎸 Transposición automática de acordes a cualquier tonalidad
- 👤 Sistema de registro y autenticación de usuarios
- 📚 Biblioteca personal de canciones guardadas
- 🔍 Búsqueda en tiempo real de canciones
- 💾 Almacenamiento persistente con SQLite
- 🎨 Interfaz moderna y responsive con TailwindCSS

## Tecnologías

- **Backend:** FastAPI 0.115.0
- **Frontend:** HTML, JavaScript, TailwindCSS
- **Base de datos:** SQLite
- **Autenticación:** JWT (JSON Web Tokens)
- **Servidor:** Uvicorn

## Instalación Local

1. Clona el repositorio:
```bash
git clone https://github.com/TU_USUARIO/song-transposer-app.git
cd song-transposer-app
```

2. Instala las dependencias:
```bash
pip install -r requirements.txt
```

3. Ejecuta la aplicación:
```bash
python main.py
```

4. Abre tu navegador en `http://localhost:8000`

## Despliegue

La aplicación está lista para desplegarse en plataformas como Render, Railway, o Heroku.

El archivo `Procfile` está configurado para el despliegue automático.

## Variables de Entorno

- `SECRET_KEY`: Clave secreta para JWT (recomendado cambiar en producción)
- `PORT`: Puerto del servidor (por defecto 8000)

## Uso

1. **Registro:** Crea una cuenta con tu nombre, email y contraseña
2. **Login:** Inicia sesión con tus credenciales
3. **Transponer:** Ingresa la letra con acordes, selecciona la tonalidad original y destino
4. **Guardar:** Tus transposiciones se guardan automáticamente en tu biblioteca
5. **Buscar:** Encuentra rápidamente tus canciones guardadas

## Estructura del Proyecto

```
song-transposer-app/
├── main.py              # Aplicación principal FastAPI
├── requirements.txt     # Dependencias Python
├── Procfile            # Configuración para despliegue
└── README.md           # Este archivo
```

## Licencia

MIT License

## Contribuciones

Las contribuciones son bienvenidas. Por favor abre un issue o pull request.

---

Creado con ❤️ usando FastAPI y TailwindCSS
